# MapStore2-theme

This repository hosts the base data to create the default theme of MapStore2. 
In the future can become a boilerplate to customize the MapStore2 theme. 

## Checking current version

The work being performed can be checked either on our [deploy server](http://lf.mapstore2.geo-solutions.it/samples/) or on rawgit [here](https://cdn.rawgit.com/geosolutions-it/MapStore2-theme/master/samples/index.html). 

## Some Hints

To see the list of the available icons, open [this site](http://bluejamesbond.github.io/CharacterMap/) and add the select the ttf font file. You will see all the available icons (actually 2 pages).
